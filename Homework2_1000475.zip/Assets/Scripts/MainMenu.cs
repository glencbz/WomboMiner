﻿using System;

namespace AssemblyCSharp
{
	public class MainMenu
	{
		public MainMenu ()
		{
		}
	}
}

